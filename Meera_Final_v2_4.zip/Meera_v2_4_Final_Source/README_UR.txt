MEERA BROKER AND TRADER'S
Business Management & Accounts System - Android
Source Package v2.0

Is package mein Android Studio / GitHub Actions ke liye Android project source hai.

Is version mein ki gayi pehli development updates:
1. Company name: MEERA BROKER AND TRADER'S
2. Business Management & Accounts System branding
3. Purchase aur Sale entry mein Item Code, Item Name, Quantity, Unit, Rate aur Paid Amount
4. Item Stock mein generic Item Name/Code, Bags, Quantity aur Unit
5. Gate Pass In / Out mein Bags aur Weight (KG)
6. Item / Process Feeding aur generic Production / Processing entry labels
7. Existing offline SQLite database, admin login, Party Accounts, JV, ledger, payments, reports, backup/restore

IMPORTANT:
- Yeh Android SOURCE code hai, APK nahi.
- APK banane ke liye GitHub Actions ya Android build environment zaroori hai.
- Is source ko pehle test build karna hoga. Abhi APK compile/test hone ka dawa nahi kiya ja raha.
- Purane installed app ko uninstall na karein jab tak backup na bana lein.


Version 2.1 UI update:
- Dashboard redesigned with KPI cards for sales, purchases, receivables and payables.
- Business modules are arranged in compact two-column cards instead of a long stack of full-width buttons.
- This ZIP is Android source code, not an APK. Build and test the APK using the included GitHub Actions workflow before business use.


Version 2.4 update: Business Management dashboard, 1/40/100 KG and custom KG options for sale/purchase, item master with automatic ITM codes, cash credit/debit entry, and edit/delete history for trade and cash entries. Source update only; APK build and device testing are still required.
