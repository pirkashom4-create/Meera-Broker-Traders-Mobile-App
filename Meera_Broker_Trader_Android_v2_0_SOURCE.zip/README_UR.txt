MEERA BROKER AND TRADER'S
Business Management & Accounts System - Android
Source Package v2.0

Is package mein Android Studio / GitHub Actions ke liye Android project source hai.

Is version mein ki gayi pehli development updates:
1. Company name: MEERA BROKER AND TRADER'S
2. Business Management & Accounts System branding
3. Purchase aur Sale entry mein Item Code, Item Name, Quantity, Unit, Rate aur Paid Amount
4. Item Stock mein generic Item Name/Code, Bags, Quantity aur Unit
5. Gate Pass In / Out mein Bags aur Weight (KG)
6. Item / Process Feeding aur generic Production / Processing entry labels
7. Existing offline SQLite database, admin login, Party Accounts, JV, ledger, payments, reports, backup/restore

IMPORTANT:
- Yeh Android SOURCE code hai, APK nahi.
- APK banane ke liye GitHub Actions ya Android build environment zaroori hai.
- Is source ko pehle test build karna hoga. Abhi APK compile/test hone ka dawa nahi kiya ja raha.
- Purane installed app ko uninstall na karein jab tak backup na bana lein.
